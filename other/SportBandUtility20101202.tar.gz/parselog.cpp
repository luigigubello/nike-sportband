#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>
#include <vector>

#define NUM_AVERAGE 51
//#define NUM_AVERAGE 1

#define WALKING_DISTANCE (1.0/149.0)
#define RUNNING_DISTANCE (1.0/184.0)

#define MILE_PER_KM 1.609344

class DistanceArray {
public:
enum UserClickType {
	USER_CLICK_STOP,
	USER_CLICK_PAUSE,
	USER_CLICK_RESUME
};
struct UserClickEvent {
	UserClickType type;
	int duration;
	const char * getTypeName() {
		const char *desc[3] = {"stop", "pause", "resume"};
		return desc[type];
	}
};
double multiply;
int numPrint;
int totalTime;
double totalDistance;
double currentDistance;
double distanceArray[NUM_AVERAGE];
static const double weightArray[][NUM_AVERAGE];
int filterType;
time_t startTime;
char empedID[20];

std::vector<double> rawData, filteredData;
std::vector<UserClickEvent> userClickList;

double walking_distance;
double running_distance;
FILE *logFile;
FILE *xmlFile;

DistanceArray() {
	filterType = 5;
	logFile = stdout;
	xmlFile = NULL;
	clear();
}

void clear() {
	totalTime = 0;
	totalDistance = 0;
	currentDistance = 0.0;
	numPrint = 0;
	for(int i = 0; i < NUM_AVERAGE; i++) {
		distanceArray[i] = 0;
	}
	running_distance = RUNNING_DISTANCE;
	walking_distance = WALKING_DISTANCE;
	multiply = walking_distance;
	rawData.clear();
	filteredData.clear();
	userClickList.clear();
}

void setOutputFile(FILE *fp) {
	logFile = fp;
}

void setFilterType(int type);

void addData(int n) {
	for(int i=NUM_AVERAGE-1; i>0; i--) {
		distanceArray[i] = distanceArray[i-1];
	}
	distanceArray[0] = n*multiply;
	rawData.push_back(n*multiply);
	totalTime++;
}

void print() {
	if(totalTime < NUM_AVERAGE/2+1) return;
	double weight = 0;
	double sum = 0;
	for(int i = 0; i < NUM_AVERAGE && i < totalTime; i++) {
		sum += distanceArray[i]*weightArray[filterType][i];
		weight += weightArray[filterType][i];
	}
	//fprintf(logFile, "%f,", sum/weight);
	totalDistance += sum/weight;
	currentDistance += sum/weight;
	filteredData.push_back(sum/weight);
	numPrint++;
	if(numPrint%10 == 0) {
		fprintf(logFile, "\n%5d, %.5f, %.5f", numPrint, totalDistance, currentDistance);
		currentDistance = 0.0;
	}
}
void flush() {
	if(totalTime < NUM_AVERAGE) {
		for(int i = 0; i < totalTime; i++) {
			//fprintf(logFile, "%d,", distanceArray[i]);
			totalDistance += distanceArray[i];
			currentDistance += distanceArray[i];
			filteredData.push_back(distanceArray[i]);
			numPrint++;
		}
		fprintf(logFile, "\n%5d, %.5f, %.5f", numPrint, totalDistance, currentDistance);
		return;
	}
	for(int j = 0; j < NUM_AVERAGE/2; j++) {
		double weight = 0;
		double sum = 0;
		for(int i = 0; i < NUM_AVERAGE-j-1; i++) {
			sum += distanceArray[i]*weightArray[filterType][i+j+1];
			weight += weightArray[filterType][i+j+1];
		}
		//fprintf(logFile, "%f,", sum/weight);
		totalDistance += sum/weight;
		currentDistance += sum/weight;
		filteredData.push_back(sum/weight);
		numPrint++;
		if(numPrint%10 == 0) {
			fprintf(logFile, "\n%5d, %.5f, %.5f", numPrint, totalDistance, currentDistance);
			currentDistance = 0.0;
		}
	}
	if(numPrint%10 != 0) {
		fprintf(logFile, "\n%5d, %.5f, %.5f", numPrint, totalDistance, currentDistance);
	}
	fprintf(logFile, "\nTotal Distance: %f km, Total Time: ", totalDistance);
	int h = totalTime/3600;
	int m = (totalTime-h*3600)/60;
	int s = totalTime-h*3600-m*60;
	fprintf(logFile, "%d:%02d:%02d\n\n", h,m,s);
}
void setWalkingDistance(double distance) {
	walking_distance = distance;
}
void setRunningDistance(double distance) {
	running_distance = distance;
}
void setWalking() {
	multiply = walking_distance;
}
void setRunning() {
	multiply = running_distance;
}
void setStartTime(time_t t) {
	startTime = t;
}
void setEmpedID(char *id) {
	strncpy(empedID, id, 11);
	empedID[11] = '\0';
}
void setUserClick(UserClickType type) {
	UserClickEvent event = {type, totalTime};
	userClickList.push_back(event);
}
bool outputXMLFile() {
	struct timeval tv;
	struct timezone tz;
	gettimeofday(&tv, &tz);
	struct tm *ts = localtime(&startTime);
	char xmlName[80];
	sprintf(xmlName, "%4d%02d%02d_%02d_%02d_%02d.xml",  ts->tm_year+1900, ts->tm_mon+1, ts->tm_mday, ts->tm_hour, ts->tm_min, ts->tm_sec);
	xmlFile = fopen(xmlName, "w");
	if(xmlFile == NULL) return false;
	fprintf(xmlFile, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n");
	fprintf(xmlFile, "<sportsData>\n");
	fprintf(xmlFile, "<userInfo>\n");
	fprintf(xmlFile, "<weight>%.1f</weight>\n", 55.0);
	fprintf(xmlFile, "<device>SportBand</device>\n");
	fprintf(xmlFile, "<empedID>%s</empedID>\n", empedID);
	fprintf(xmlFile, "<calibration/>\n");
	fprintf(xmlFile, "</userInfo>\n");
	fprintf(xmlFile, "<runSummary hasHRS=\"false\" workoutType=\"standard\">\n");
//	fprintf(xmlFile, "<time>%04d-%02d-%02dT%02d:%02d:%02d+%02d:%02d</time>\n", ts->tm_year+1900, ts->tm_mon+1, ts->tm_mday, ts->tm_hour, ts->tm_min, ts->tm_sec, -tz.tz_minuteswest/60, abs(tz.tz_minuteswest)%60);
	fprintf(xmlFile, "<distance unit=\"km\">%f</distance>\n", totalDistance);
	fprintf(xmlFile, "<duration>%d</duration>\n", totalTime*1000);
	fprintf(xmlFile, "<calories>%d</calories>\n", 0);
	fprintf(xmlFile, "<equipmentType>sportband</equipmentType>\n");
	fprintf(xmlFile, "</runSummary>\n");
	fprintf(xmlFile, "<batteryLifetime>%d</batteryLifetime>\n", 0);
//	fprintf(xmlFile, "<template>\n");
//	fprintf(xmlFile, "<templateName>\n");
//	fprintf(xmlFile, "<![CDATA[Basic]]>\n");
//	fprintf(xmlFile, "</templateName>\n");
//	fprintf(xmlFile, "</template>\n");
//	fprintf(xmlFile, "<goal type=\"\" unit=\"\" value=\"\">\n");
	fprintf(xmlFile, "<startTime>%04d-%02d-%02dT%02d:%02d:%02d+%02d:%02d</startTime>\n", ts->tm_year+1900, ts->tm_mon+1, ts->tm_mday, ts->tm_hour, ts->tm_min, ts->tm_sec, -tz.tz_minuteswest/60, abs(tz.tz_minuteswest)%60);
	int duration=0, lapDuration = 0;
	double distance=0, lapDistance = 0, next_split;

	fprintf(xmlFile, "<snapShotList snapShotType=\"kmSplit\">\n");
	next_split = 1.0;
	for(int i = 0; i < filteredData.size(); i++) {
		duration++;
		lapDuration++;
		distance += filteredData[i];
		lapDistance += filteredData[i];
		if(distance > next_split) {
			fprintf(xmlFile, "<snapShot>\n");
			fprintf(xmlFile, "<pace>%.0f</pace>\n", lapDuration*1000/lapDistance);
			fprintf(xmlFile, "<distance>%f</distance>\n", distance);
			fprintf(xmlFile, "<duration>%d</duration>\n", duration*1000);
			fprintf(xmlFile, "</snapShot>\n");
			next_split += 1.0;
			lapDistance = 0;
			lapDuration = 0;
		}
	}
	fprintf(xmlFile, "</snapShotList>\n");

	fprintf(xmlFile, "<snapShotList snapShotType=\"userClick\">\n");
	int userClickIndex = 0;
	distance = 0;
	duration = 0;
	lapDistance = 0;
	lapDuration = 0;
	for(int i = 0; i < filteredData.size(); i++) {
		duration++;
		lapDuration++;
		distance += filteredData[i];
		lapDistance += filteredData[i];
		if(duration == userClickList[userClickIndex].duration) {
			fprintf(xmlFile, "<snapShot event=\"%s\">\n", userClickList[userClickIndex].getTypeName());
			fprintf(xmlFile, "<pace>%.0f</pace>\n", lapDuration*1000/lapDistance);
			fprintf(xmlFile, "<distance>%f</distance>\n", distance);
			fprintf(xmlFile, "<duration>%d</duration>\n", duration*1000);
			fprintf(xmlFile, "</snapShot>\n");
			userClickIndex++;
			if(userClickIndex >= userClickList.size()) break;
			lapDistance = 0;
			lapDuration = 0;
		}
	}
	fprintf(xmlFile, "</snapShotList>\n");

	distance = 0;
	duration = 0;
	lapDistance = 0;
	lapDuration = 0;
	fprintf(xmlFile, "<snapShotList snapShotType=\"mileSplit\">\n");
	next_split = MILE_PER_KM;
	for(int i = 0; i < filteredData.size(); i++) {
		duration++;
		lapDuration++;
		distance += filteredData[i];
		lapDistance += filteredData[i];
		if(distance > next_split) {
			fprintf(xmlFile, "<snapShot>\n");
			fprintf(xmlFile, "<pace>%.0f</pace>\n", lapDuration*1000/lapDistance);
			fprintf(xmlFile, "<distance>%f</distance>\n", distance);
			fprintf(xmlFile, "<duration>%d</duration>\n", duration*1000);
			fprintf(xmlFile, "</snapShot>\n");
			next_split += MILE_PER_KM;
			lapDistance = 0;
			lapDuration = 0;
		}
	}
	fprintf(xmlFile, "</snapShotList>\n");

	fprintf(xmlFile, "<extendedDataList>\n");
	fprintf(xmlFile, "<extendedData dataType=\"distance\" intervalType=\"time\" intervalUnit=\"s\" intervalValue=\"10\">\n");
	distance = 0;
	for(int i = 0; i < filteredData.size(); i++) {
		distance += filteredData[i];
		if((i % 10) == 9) {
			fprintf(xmlFile, "%.4f", distance);
			if(i/10 < filteredData.size()/10-1) {
				fprintf(xmlFile, ", "); 
				if((i%80) == 79) fprintf(xmlFile, "\n");
			}
			else {
				fprintf(xmlFile, "\n");
			}
		}
	}
	fprintf(xmlFile, "</extendedData>\n");
	fprintf(xmlFile, "</extendedDataList>\n");
	fprintf(xmlFile, "</sportsData>\n");

	return false;
}
};

DistanceArray distanceArray;

bool getData(FILE *fp, int *data) {
	unsigned char b[2];
	while(fread(b, 1, 2, fp) == 2) {
		*data = (b[0]<<8)|b[1];
		if(*data == 0xffff) continue;
		return true;
	}
	return false;
}
bool printStartCode(FILE *fp, char empedID[]) {
	unsigned char b[24];
	int d;
	for(int i=0; i < 24; i+=2) {
		getData(fp, &d);
		b[i] = d >> 8;
		b[i+1] = d & 0xff;
	}
	printf("\n    [%02x ", b[0]);
	for(int i=1; i < 12; i++) {
		empedID[i-1] = b[i];
		if(isprint(b[i])) {
			printf("%c", b[i]);
		}
		else {
			printf(".");
		}
	}
	for(int i=12; i < 16; i++) {
		printf(" %02x", b[i]);
	}
	float f;
	((unsigned char*)&f)[3] = b[16];
	((unsigned char*)&f)[2] = b[17];
	((unsigned char*)&f)[1] = b[18];
	((unsigned char*)&f)[0] = b[19];
	printf(" %f", f);
	distanceArray.setWalkingDistance(1.0/f * 0.000171735);
	((unsigned char*)&f)[3] = b[20];
	((unsigned char*)&f)[2] = b[21];
	((unsigned char*)&f)[1] = b[22];
	((unsigned char*)&f)[0] = b[23];
	printf(" %f", f);
	distanceArray.setRunningDistance(1.0/f * 0.000171735);
	printf("]");
	return true;
}
bool printEndCode(FILE *fp) {
	unsigned char b[6];
	int d;
	for(int i=0; i < 6; i+=2) {
		getData(fp, &d);
		b[i] = d >> 8;
		b[i+1] = d & 0xff;
	}
	printf("\n    [");
	for(int i=0; i < 6; i++) {
		printf("%02x ", b[i]);
	}
	printf("]\n");
	return true;
}
time_t printTime(FILE *fp) {
	struct tm *ts;
	time_t t;
	int d1, d2;
	getData(fp, &d1);
	getData(fp, &d2);
	t = (d1 << 16)|d2;
	ts = localtime(&t);
	printf("%4d/%d/%d %02d:%02d:%02d", ts->tm_year+1900, ts->tm_mon+1, ts->tm_mday, ts->tm_hour, ts->tm_min, ts->tm_sec);
	return t;
	
}

const double DistanceArray::weightArray[][NUM_AVERAGE] = {
#if 0
// Weight for moving average (smoothing the data)
/*0*/	{0,0,0,0,0,1.0,0.0,0.0,0.0,0.0,0}, // No smoothing
/*1*/	{0,0,0,0,0,1.0,0.5,0.25,0.125,0.0625,0.0},
/*2*/	{0,0,0,0,0,1.0,0.7,0.2,0.0,0.0,0},
/*3*/	{0,0,0,0,0,1.0,0.9,0.3,0.2,0.1,0.05},
/*4*/	{0,0,0,0,0,1.0,0.9,0.4,0.2,0.15,0.1},
/*5*/	{0,0,0,0,0,1,1,1,1,1,1},

/*6*/	{0.00243, 0.0081, 0.027, 0.09, 0.3, 1.0, 0.3, 0.09, 0.027, 0.0081, 0.00243},
/*7*/	{0.01024, 0.0256, 0.064, 0.16, 0.4, 1.0, 0.4, 0.16, 0.064, 0.0256, 0.01024},
/*8*/	{0.0,     0.0,    0.125, 0.25, 0.5, 1.0, 0.5, 0.25, 0.125, 0.0,    0.0},
/*9*/	{0.0,     0.0625, 0.125, 0.25, 0.5, 1.0, 0.5, 0.25, 0.125, 0.0625, 0.0},
/*10*/	{0.03125, 0.0625, 0.125, 0.25, 0.5, 1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125},
/*11*/	{0.02,    0.05,   0.1,   0.3,  0.5, 1.0, 0.5, 0.3,  0.1,   0.05,   0.02},
/*12*/	{0.05,    0.1,    0.2,   0.4,  0.8, 1.0, 0.8, 0.4,  0.2,   0.1,    0.05},
/*13*/	{1,1,1,1,1,1,1,1,1,1,1},

/*14*/	{0.03125, 0.0625, 0.125, 0.25, 0.5, 1.0, 0.0, 0.0,  0.0,   0.0,    0.0},
/*15*/	{1,1,1,1,1,1,0,0,0,0,0},
#else
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 1,
 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
 1,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
 1,
 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 1,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,3,4,5,6,7,8,9,
 10,
 9,8,7,6,5,4,3,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
1.0,
0.7,0.2,0.0,0.0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
#endif
};
void DistanceArray::setFilterType(int type) {
	if(type >= sizeof(weightArray)/sizeof(double)/NUM_AVERAGE) {
		type = 2;
	}
	filterType = type;
}

int bindata[8];

void printDistance(int data) {
	int secs, fr, to;

	switch(data & 0xf000) {
		case 0x0000:
		case 0x1000:
		case 0x2000:
		case 0x3000:
		case 0x4000:
		case 0x5000:
		case 0x6000:
		case 0x7000:
			secs = 5;
			fr = 4;
			to = 0;
			break;
		case 0xd000:
			secs = 2;
#if 1
			if(data & 0x0007) {
				fr = 1;
				to = 0;
			}else if(data & 0x0038) {
				fr = 2;
				to = 1;
			} else {
				fr = 3;
				to = 2;
			}
#else
			fr = 1;
			to = 0;
#endif
			break;
		case 0xb000:
		case 0x8000:
			secs = 1;
#if 1
			if(data & 0x0007) {
				fr = 0;
				to = 0;
			}else if(data & 0x0038) {
				fr = 1;
				to = 1;
			}else if(data & 0x01c0) {
				if(data == 0x8080) {
					data = 0x8001;
					fr = 0;
					to = 0;
				} else {
					fr = 2;
					to = 2;
				}
			} else {
				fr = 3;
				to = 3;
			}
#else
			fr = 0;
			to = 0;
#endif
			break;
		default:
			secs = 0;
			printf("\nUnexpected data %04x", data);
			return;
	}
	for(int i=fr; i >= to; i--) {
		int currentDistance =  (data >> (i*3)) & 7;
		bindata[currentDistance]++;
		if(currentDistance == 7) {
			currentDistance = 0;
		}
		distanceArray.addData(currentDistance);
		distanceArray.print();
	}
}

main(int argc, char **argv) {
	FILE *fp = NULL, *outFp = NULL;
	int data;
	bool printRawData = false;
	while(argc > 1) {
		++argv;
		--argc;
		if(argv[0][0] == '-') {
			if(argv[0][1] == 'v') {
				printRawData = true;
				continue;
			}
			if(argv[0][1] == 'f') {
				distanceArray.setFilterType(atoi(argv[0]+2));
				continue;
			}
			fprintf(stderr, "Unexpected option: %s\n", argv[0]);
			continue;
		}
		if(fp == NULL) {
			fp = fopen(argv[0], "rb");
			if(fp == NULL) {
				fprintf(stderr, "File open error:%s\n", argv[0]);
				exit(1);
			}
			continue;
		}
		if(outFp == NULL) {
			outFp = fopen(argv[0], "w");
			if(outFp != NULL) {
				distanceArray.setOutputFile(outFp);
			}
			else {
				fprintf(stderr, "Open output file error\n");
				exit(1);
			}
		}
	}
	if(fp == NULL) {
		fprintf(stderr, "Usage: parselog [-v] input [output]\n");
		exit(1);
	}

	time_t t;
	char empedID[20];
	while(getData(fp, &data)) {
		switch(data) {
			case 0xe300:
				printf("\n=== Start File ===");
				break;
			case 0xe800:
				printf("\n=== Start Log  ");
				t = printTime(fp);
				printStartCode(fp, empedID);
				distanceArray.setStartTime(t);
				distanceArray.setEmpedID(empedID);
				break;
			case 0xe900:
				distanceArray.setUserClick(DistanceArray::USER_CLICK_STOP);
				distanceArray.flush();
				distanceArray.outputXMLFile();
				distanceArray.clear();
				printf("\n=== End Log  ");
				printTime(fp);
				printEndCode(fp);
				break;
			case 0xea00:
				distanceArray.setUserClick(DistanceArray::USER_CLICK_PAUSE);
				printf("\n=== Pause ");
				printTime(fp);
				break;
			case 0xeb00:
				distanceArray.setUserClick(DistanceArray::USER_CLICK_RESUME);
				printf("\n=== Resume ");
				printTime(fp);
				break;
			case 0xe200:
				distanceArray.setRunning();
				if(printRawData) printf("\n>>> Running ");
				break;
			case 0xe201:
				distanceArray.setWalking();
				if(printRawData) printf("\n<<< Walking ");
				break;
			case 0xe31f:
				if(printRawData) printf("\nUnknown code 0xe31f ");
				break;
			default:
				if(printRawData) {
					//printf("\n%04x, ", data);
					printf("\n%d,%d,%d,%d,%d,%d, ",
						(data>>15),
						(data>>12)&7,
						(data>>9)&7,
						(data>>6)&7,
						(data>>3)&7,
						data&7);
				}
				printDistance(data);
				break;
		}
	}
	printf("\n");

	for(int i = 0; i < 8; i++) {
		printf("%d, %d\n", i, bindata[i]);
	}
}

/*

$B%m%0$N%o!<%I?t$H%"%/%F%#%S%F%#$N;~4V$+$i7W;;$9$k$HLs(B5$BICKh$K(B
16$B%S%C%H%G!<%?$,5-O?$5$l$F$$$k(B

$B%U%C%H%]%C%I$O2CB.EY$r8!CN$9$k$H%G!<%?$rE>Aw$9$k!#(B
$B%G!<%?$r<u?.$7$?%j%9%H%P%s%I$O(B5$BIC$4$H$K%U%C%I%]%C%I$+$i<u?.$7$?%G!<%?$r5-O?$9$k(B
$BDd;_$9$k$H%U%C%H%]%C%I$O%G!<%?$NE>Aw$rDd;_$9$k!#%G!<%?$,<u?.$G$-$J$+$C$?>l9g(B
$B%j%9%H%P%s%I$O(B0x7fff$B$r5-O?$9$k$H;W$o$l$k(B

$B%&%)!<%-%s%0"*%i%s%K%s%0$KJQ$o$C$?>l9g(B0xe200$B$,5-O?$5$l$k(B
$B%i%s%K%s%0"*%&%)!<%-%s%0$KJQ$o$C$?>l9g(B0xe201$B$,5-O?$5$l$k(B
*/
