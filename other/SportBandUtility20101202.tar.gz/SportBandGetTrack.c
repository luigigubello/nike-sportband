#include <stdio.h>
#include <string.h>
#include <usb.h>

main(int argc, char **argv) {
  struct usb_bus *bus;
  usb_dev_handle *handle = NULL;
  int interface;
  int err;
  unsigned char buff[64];
  char *fileName;

  FILE *fp;

  if(argc > 1 && argv[1] != NULL) {
    fileName = argv[1];
  }
  else {
    fileName = "SportBand.dump";
  }
  
  seteuid(0);

  usb_init();
  usb_set_debug(0);

  usb_find_busses();
  usb_find_devices();

  for (bus = usb_get_busses(); bus; bus = bus->next) {
    struct usb_device *dev;

    for (dev = bus->devices; dev; dev = dev->next) {
      if(dev->descriptor.idVendor == 0x11ac && dev->descriptor.idProduct == 0x4269) {
        handle = usb_open(dev);
/*
	err = usb_set_configuration(handle, dev->config->bConfigurationValue);
	if(err < 0) {
	  printf("set configuration failed\n");
  	  usb_release_interface(handle, interface);
  	  usb_close(handle);
	  exit(1);
	}
*/
	interface = dev->config->interface->altsetting->bInterfaceNumber;
	err = usb_claim_interface(handle, interface);
	if(err < 0) {
	  usb_detach_kernel_driver_np(handle, interface);
	  err = usb_claim_interface(handle, interface);
	  if(err < 0) {
	    fprintf(stderr, "claim interface failed\n");
  	    usb_release_interface(handle, interface);
  	    usb_close(handle);
	    exit(1);
	  }
	}
	break;
      }
    }
  }

  if(handle == NULL) {
    fprintf(stderr, "No sportband found\n");
    exit(1);
  }
  fp = fopen(fileName, "ab");
  if(fp == NULL) {
    fprintf(stderr, "File open error\n");
  }

// Get PIN, user name etc...
  memset(buff, '\0', 64);
  buff[0] = '\x09';
  buff[1] = '\x04';
  buff[2] = '\x52';
  buff[3] = '\x34';

  err = usb_control_msg(handle, 0x21, 0x09, 0x0209, 0x0, buff, 0x8, 1000);

  if(err < 0) {
    fprintf(stderr, "Error: control write: %d\n", err);
    exit(1);
  }
  //while(1) {
    memset(buff, '\0', 64);
    err = usb_control_msg(handle, 0xa1, 0x01, 0x0104, 0x0, buff, 0x40, 1000);
    if(err == 0) {
    //  break;
    }
    if(err < 0) {
      fprintf(stderr, "Error: control read: %d\n", err);
      exit(1);
    }
    //if(buff[1] < 2) {
    //  break;
    //}
    //fwrite(&buff[5], 1, buff[1]-3, fp);
  //}
  buff[9+36] = '\0';
  printf("PIN=%s\n", &buff[9]);

//Get Weight
  memset(buff, '\0', 64);
  buff[0] = '\x09';
  buff[1] = '\x02';
  buff[2] = '\x51';
  buff[3] = '\x33';

  err = usb_control_msg(handle, 0x21, 0x09, 0x0209, 0x0, buff, 0x8, 1000);

  if(err < 0) {
    fprintf(stderr, "Error: control write: %d\n", err);
    exit(1);
  }
  memset(buff, '\0', 64);
  err = usb_control_msg(handle, 0xa1, 0x01, 0x0101, 0x0, buff, 0x08, 1000);
  if(err == 0) {
    //break;
  }
  if(err < 0) {
    fprintf(stderr, "Error: control read: %d\n", err);
    exit(1);
  }
  double weight = ((buff[3]<<8)|buff[4])/2.2046/10;
  printf("weight=%.1f\n", weight);
  memset(buff, '\0', 64);
  buff[0] = '\x09';
  buff[1] = '\x05';
  buff[2] = '\x0c';
  buff[3] = '\x10';

  err = usb_control_msg(handle, 0x21, 0x09, 0x0209, 0x0, buff, 0x8, 1000);

  if(err < 0) {
    fprintf(stderr, "Error: control write: %d\n", err);
    exit(1);
  }
  //fp = fopen(fileName, "ab");
  //if(fp == NULL) {
  //  fprintf(stderr, "File open error\n");
  //}
  while(1) {
    memset(buff, '\0', 64);
    err = usb_control_msg(handle, 0xa1, 0x01, 0x0104, 0x0, buff, 0x40, 1000);
    if(err == 0) {
      break;
    }
    if(err < 0) {
      fprintf(stderr, "Error: control read: %d\n", err);
      exit(1);
    }
    if(buff[1] < 5) {
      break;
    }
    fwrite(&buff[7], 1, buff[1]-5, fp);
  }
  fclose(fp);
  usb_release_interface(handle, interface);
  usb_close(handle);
  return 0;
}
